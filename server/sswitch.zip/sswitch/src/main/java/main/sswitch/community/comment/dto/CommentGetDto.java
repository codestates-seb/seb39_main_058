package main.sswitch.community.comment.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CommentGetDto {

    private long commentId;

    private long forumId;
}
