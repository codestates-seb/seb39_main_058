package main.sswitch.community.forum.dto;

import main.sswitch.community.forum.entity.Forum;

public class ForumSearchDto {
    private long forumId;

    private Forum.Genre genre;

    private String forumTitle;

    private Forum.Secret secret;

}
