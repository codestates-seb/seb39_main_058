package main.sswitch.community.forum.dto;

import main.sswitch.community.forum.entity.Forum;
import main.sswitch.community.comment.entity.Comment;

import java.time.LocalDateTime;
import java.util.List;

public class ForumResponseDto {

    private long forumId;

    private Forum.Genre genre;

    private Forum.Secret secret;

    private String forumTitle;

    private String forumText;

    private long forumLike;

    private LocalDateTime createdAt;

    private LocalDateTime modifiedAt;

    private String username;

    private List<Comment> comments;
}
