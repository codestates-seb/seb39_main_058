package main.sswitch.news.notice.service;

import main.sswitch.exceptions.BusinessLogicException;
import main.sswitch.exceptions.ExceptionCode;
import main.sswitch.news.notice.entity.Notice;
import main.sswitch.news.notice.repository.NoticeRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class NoticeService {

    private final NoticeRepository noticeRepository;

    public NoticeService(NoticeRepository noticeRepository){
        this.noticeRepository = noticeRepository;
    }

    public Notice createNotice(Notice notice) {
        //이미 등록된 공지사항인지 확인
        verifyExistNotice(notice.getNoticeId());
        //관리자인지 확인
//        verifyUserRole(notice.getUserRole());

        return noticeRepository.save(notice);
    }

    public Notice updateNotice(Notice notice) {
        //조회하려는 공지사항이 존재하는지 확인
        Notice findNotice = findVerifiedNotice(notice.getNoticeId());
        //관리자인지 확인
//        verifyUserRole(notice.getUserRole());

        Optional.ofNullable(notice.getNoticeTitle())
                .ifPresent(noticeTitle -> findNotice.setNoticeTitle(noticeTitle));
        Optional.ofNullable(notice.getNoticeText())
                .ifPresent(noticeText -> findNotice.setNoticeText(noticeText));

        return noticeRepository.save(findNotice);
    }

    public Notice findNotice(long noticeId) {
        return findVerifiedNoticeByQuery(noticeId);
    }

    public Page<Notice> findNotices(int page, int size) {
        return noticeRepository.findAll(PageRequest.of(page, size,
                Sort.by("noticeId").descending()));
    }

    public void deleteNotice(long noticeId) {
        Notice notice = findVerifiedNotice(noticeId);
        //관리자인지 확인
//        verifyUserRole(notice.getUserRole());

        noticeRepository.delete(notice);
    }

    public Notice findVerifiedNotice(long noticeId) {
        Optional<Notice> optionalNotice = noticeRepository.findById(noticeId);
        Notice findNotice =
                optionalNotice.orElseThrow(() ->
                        new BusinessLogicException(ExceptionCode.NOTICE_NOT_FOUND));

        return findNotice;
    }

    public void verifyExistNotice(long noticeId) {
        Optional<Notice> notice = noticeRepository.findById(noticeId);
        if (notice.isPresent()) {
            throw new BusinessLogicException(ExceptionCode.NOTICE_EXISTS);
        }
    }

    public Notice findVerifiedNoticeByQuery(long noticeId) {
        Optional<Notice> optionalNotice = noticeRepository.findByNotice(noticeId);
        Notice findNotice =
                optionalNotice.orElseThrow(() ->
                        new BusinessLogicException(ExceptionCode.NOTICE_NOT_FOUND));

        return findNotice;
    }

//    public void verifyUserRole(String userRole) {
//
//    }
}
