package main.sswitch.trash.dto;

import lombok.Getter;
import lombok.Setter;
import main.sswitch.trash.entity.TrashCan;

import javax.validation.constraints.NotNull;

@Getter
@Setter
public class TrashStatusDto {
    private long trashId;

    @NotNull
    private TrashCan.TrashStatus trashStatus;


}
